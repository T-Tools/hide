<html>
<title>Admin Panel</title>
<style>
body {
    background: #3e4144;
    background-image:/images/adminbg;
}
p.security{
    color:red;
}
.form {
    margin: 50px auto;
    width: 300px;
    padding: 30px 25px;
    background: white;
}
h1.login-title {
    color: green;
    margin: 0px auto 25px;
    font-size: 35px;
    font-weight: 300;
    text-align: center;
}
.login-input {
    font-size: 15px;
    border: 1px solid #ccc;
    padding: 10px;
    margin-bottom: 25px;
    height: 25px;
    width: calc(100% - 23px);
}
.login-input:focus {
    border-color:#6e8095;
    outline: none;
}
.login-button {
    color: #fff;
    background: #55a1ff;
    border: 0;
    outline: 0;
    width: 100%;
    height: 50px;
    font-size: 16px;
    text-align: center;
    cursor: pointer;
}
.link {
    color: #666;
    font-size: 15px;
    text-align: center;
    margin-bottom: 0px;
}
.link a {
    color: #666;
}
h3 {
    font-weight: normal;
    text-align: center;
}
</style>

<body>
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<center> <form action="../Admin/login.php" class="form" method="post" name="login">
        <h1 class="login-title">Login Panel</h1>
        <input type="text" class="login-input" name="username" placeholder="Username" autofocus="true"/>
        <input type="password" class="login-input" name="password" placeholder="Password"/>
       
        <input type="submit" value="Login" name="submit" class="login-button"/>

  </form><center>
</body>
</html>