<?php
session_start();
$mail = $_POST['username'] ;
$password = $_POST['password'] ;
   $mydata = simplexml_load_file("1123747499393039446/47899556sjwjwj26192878");
    for($i = 0; $i < count($mydata->data->account); $i++){

        $login = $mydata->data->account[$i]->username;
        $pass = $mydata->data->account[$i]->password;
if ($mail == $login && $pass == $password){
$_SESSION['username']="$mail";
$_SESSION['password']="$password";
header("Location:../Admin/user.php");
}
else {
header("Location:index.php");
}
}
?>